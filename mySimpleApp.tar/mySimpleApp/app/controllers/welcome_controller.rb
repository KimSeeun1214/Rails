class WelcomeController < ApplicationController
  def index
	@message = "Hello! It is me!!!"
	@count = 3
	@explanation = "This mesaage came from the cotroller."
  end
end
